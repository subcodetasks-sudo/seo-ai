=== AI SEO Platform ===
Contributors: aiseoplatform
Tags: seo, meta, optimization, ai
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later

Connect your WordPress site to AI SEO Platform for automated SEO analysis.

== Description ==
AI SEO Platform analyses every page of your site, generates AI-powered SEO improvements,
and lets you apply them with one click — directly to your WordPress database.

== Installation ==
1. Upload the plugin zip via Plugins > Add New > Upload Plugin
2. Activate the plugin
3. Go to Settings > AI SEO Platform and copy your connection token
4. Paste the token in your AI SEO Platform dashboard

== Changelog ==
= 1.0.0 =
* Initial release
