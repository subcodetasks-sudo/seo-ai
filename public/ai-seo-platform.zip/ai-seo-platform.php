<?php
/**
 * Plugin Name:       AI SEO Platform
 * Plugin URI:        https://howeyah-rank.cloud
 * Description:       Connect your WordPress site to AI SEO Platform for automated SEO analysis and one-click improvements.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            AI SEO Platform
 * License:           GPL v2 or later
 * Text Domain:       ai-seo-platform
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'AI_SEO_PLATFORM_VERSION', '1.0.0' );
define( 'AI_SEO_PLATFORM_DIR', plugin_dir_path( __FILE__ ) );
define( 'AI_SEO_PLATFORM_URL', plugin_dir_url( __FILE__ ) );
define( 'AI_SEO_BRIDGE_TOKEN_KEY', 'ai_seo_bridge_token' );

require_once AI_SEO_PLATFORM_DIR . 'includes/class-activator.php';
require_once AI_SEO_PLATFORM_DIR . 'includes/class-admin-page.php';
require_once AI_SEO_PLATFORM_DIR . 'includes/class-read-api.php';
require_once AI_SEO_PLATFORM_DIR . 'includes/class-write-api.php';

register_activation_hook( __FILE__, array( 'AI_SEO_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'AI_SEO_Activator', 'deactivate' ) );

add_action( 'rest_api_init', array( 'AI_SEO_Read_API', 'register_routes' ) );
add_action( 'rest_api_init', array( 'AI_SEO_Write_API', 'register_routes' ) );
add_action( 'admin_menu', array( 'AI_SEO_Admin_Page', 'add_menu' ) );
add_action( 'init', array( 'AI_SEO_Admin_Page', 'register' ) );
