=== Howeyah Rank ===
Contributors: aiseoplatform
Tags: seo, meta, optimization, ai
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later

Connect your WordPress site to Howeyah Rank for automated SEO analysis.

== Description ==
Howeyah Rank analyses every page of your site, generates AI-powered SEO improvements,
and lets you apply them with one click — directly to your WordPress database.

== Installation ==
1. Upload the plugin zip via Plugins > Add New > Upload Plugin
2. Activate the plugin
3. Go to Settings > Howeyah Rank and copy your connection token
4. Paste the token in your Howeyah Rank dashboard

== Changelog ==
= 1.0.0 =
* Initial release
