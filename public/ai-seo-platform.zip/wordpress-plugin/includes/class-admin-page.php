<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AI_SEO_Admin_Page {

    const PAGE_SLUG = 'ai-seo-platform';

    public static function add_menu(): void {
        add_options_page(
            'Howeyah Rank',
            'Howeyah Rank',
            'manage_options',
            self::PAGE_SLUG,
            array( self::class, 'render_page' )
        );
    }

    /**
     * Register the AJAX handlers. Called at plugin load (admin-ajax.php does
     * not fire admin_menu, so these can't live in add_menu()).
     */
    public static function register(): void {
        add_action( 'wp_ajax_ai_seo_connect', array( self::class, 'handle_connect' ) );
        add_action( 'wp_ajax_ai_seo_disconnect', array( self::class, 'handle_disconnect' ) );
    }

    /**
     * Settings page. Section 1 (connect form) when not connected; Section 2
     * (status + disconnect) when connected.
     */
    public static function render_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'ai-seo-platform' ) );
        }

        $is_connected = get_option( 'ai_seo_connection_status' ) === 'connected';
        $token        = AI_SEO_Activator::get_token();
        $site_name    = get_bloginfo( 'name' );
        $site_url     = get_site_url();
        $platform_url = get_option( 'ai_seo_platform_url', 'https://portal.howeyah-rank.cloud' );
        $project_name = get_option( 'ai_seo_connected_project', '' );
        $nonce        = wp_create_nonce( 'ai_seo_connect_nonce' );
        $ajax_url     = admin_url( 'admin-ajax.php' );
        $token_hint   = strlen( $token ) > 8 ? substr( $token, 0, 8 ) . '••••••••' : '••••••••';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

            <?php if ( $is_connected ) : ?>

                <div class="notice notice-success">
                    <p>✅ <strong><?php esc_html_e( 'Connected', 'ai-seo-platform' ); ?></strong></p>
                </div>

                <table class="form-table">
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Project', 'ai-seo-platform' ); ?></th>
                        <td><?php echo esc_html( $project_name ); ?></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Site', 'ai-seo-platform' ); ?></th>
                        <td><code><?php echo esc_html( $site_url ); ?></code></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Token', 'ai-seo-platform' ); ?></th>
                        <td><code><?php echo esc_html( $token_hint ); ?></code></td>
                    </tr>
                </table>

                <p>
                    <button type="button" class="button" id="ai_seo_disconnect_btn">
                        <?php esc_html_e( 'Disconnect', 'ai-seo-platform' ); ?>
                    </button>
                </p>
                <div id="ai_seo_connect_result" style="margin-top:12px;"></div>

            <?php else : ?>

                <h2><?php esc_html_e( 'Connect to Howeyah Rank', 'ai-seo-platform' ); ?></h2>

                <table class="form-table">
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Site Name', 'ai-seo-platform' ); ?></th>
                        <td><?php echo esc_html( $site_name ); ?></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Site URL', 'ai-seo-platform' ); ?></th>
                        <td><code><?php echo esc_html( $site_url ); ?></code></td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ai_seo_setup_token"><?php esc_html_e( 'Setup Token', 'ai-seo-platform' ); ?></label>
                        </th>
                        <td>
                            <input type="text"
                                   class="regular-text"
                                   id="ai_seo_setup_token"
                                   name="ai_seo_setup_token"
                                   placeholder="<?php esc_attr_e( 'Paste your setup token from the platform', 'ai-seo-platform' ); ?>" />
                            <p class="description"><?php esc_html_e( 'Find this in your platform dashboard under Project → WordPress Setup', 'ai-seo-platform' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ai_seo_platform_url"><?php esc_html_e( 'Platform URL', 'ai-seo-platform' ); ?></label>
                        </th>
                        <td>
                            <input type="text"
                                   class="regular-text"
                                   id="ai_seo_platform_url"
                                   name="ai_seo_platform_url"
                                   placeholder="https://portal.howeyah-rank.cloud"
                                   value="<?php echo esc_attr( $platform_url ); ?>" />
                            <p class="description"><?php esc_html_e( 'The URL of your Howeyah Rank — the site address only (e.g. https://portal.howeyah-rank.cloud), NOT the setup link or token.', 'ai-seo-platform' ); ?></p>
                        </td>
                    </tr>
                </table>

                <p>
                    <button type="button" class="button button-primary" id="ai_seo_connect_btn">
                        <?php esc_html_e( 'Connect to Platform', 'ai-seo-platform' ); ?>
                    </button>
                </p>
                <div id="ai_seo_connect_result" style="margin-top:12px;"></div>

            <?php endif; ?>
        </div>

        <script type="text/javascript">
        (function () {
            var ajaxUrl  = <?php echo wp_json_encode( $ajax_url ); ?>;
            var nonce    = <?php echo wp_json_encode( $nonce ); ?>;
            var wpToken  = <?php echo wp_json_encode( $token ); ?>;
            var siteUrl  = <?php echo wp_json_encode( $site_url ); ?>;
            var siteName = <?php echo wp_json_encode( $site_name ); ?>;

            function postAjax( params, cb ) {
                var body = new URLSearchParams( params );
                fetch( ajaxUrl, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: body.toString()
                } )
                .then( function ( r ) { return r.json(); } )
                .then( cb )
                .catch( function () { cb( { success: false, data: { message: 'Network error' } } ); } );
            }

            function showError( msg ) {
                var box = document.getElementById( 'ai_seo_connect_result' );
                if ( ! box ) { return; }
                var notice = document.createElement( 'div' );
                notice.className = 'notice notice-error';
                var p = document.createElement( 'p' );
                p.textContent = '❌ ' + msg;
                notice.appendChild( p );
                box.innerHTML = '';
                box.appendChild( notice );
            }

            var connectBtn = document.getElementById( 'ai_seo_connect_btn' );
            if ( connectBtn ) {
                connectBtn.addEventListener( 'click', function () {
                    var setupToken  = ( document.getElementById( 'ai_seo_setup_token' ) || {} ).value || '';
                    var platformUrl = ( document.getElementById( 'ai_seo_platform_url' ) || {} ).value || '';
                    connectBtn.disabled = true;
                    connectBtn.textContent = 'Connecting...';
                    postAjax( {
                        action: 'ai_seo_connect',
                        nonce: nonce,
                        setup_token: setupToken,
                        platform_url: platformUrl,
                        wp_token: wpToken,
                        site_url: siteUrl,
                        site_name: siteName
                    }, function ( resp ) {
                        if ( resp && resp.success ) {
                            location.reload();
                        } else {
                            var msg = ( resp && resp.data && resp.data.message ) ? resp.data.message : 'Connection failed';
                            showError( msg );
                            connectBtn.disabled = false;
                            connectBtn.textContent = 'Connect to Platform';
                        }
                    } );
                } );
            }

            var disconnectBtn = document.getElementById( 'ai_seo_disconnect_btn' );
            if ( disconnectBtn ) {
                disconnectBtn.addEventListener( 'click', function () {
                    disconnectBtn.disabled = true;
                    postAjax( { action: 'ai_seo_disconnect', nonce: nonce }, function () {
                        location.reload();
                    } );
                } );
            }
        })();
        </script>
        <?php
    }

    /**
     * Reduce a pasted Platform URL to its origin: scheme://host[:port].
     *
     * Users often paste the full setup link from the dashboard
     * (https://platform/wp-setup?token=...) or a URL with a trailing path.
     * Only the origin identifies the platform — the register endpoint path is
     * appended by this plugin — so anything after the host must be dropped or
     * the request 404s and is misreported as an invalid setup token.
     */
    private static function normalize_platform_url( string $platform_url ): string {
        $parts = wp_parse_url( trim( $platform_url ) );
        if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
            return $platform_url; // unparseable — leave as-is, validation below handles empties
        }
        $origin = $parts['scheme'] . '://' . $parts['host'];
        if ( ! empty( $parts['port'] ) ) {
            $origin .= ':' . $parts['port'];
        }
        return $origin;
    }

    /**
     * AJAX: send {setup_token, wp_token, site_url, site_name} to the platform's
     * /plugin/register endpoint and record the resulting connection status.
     */
    public static function handle_connect(): void {
        check_ajax_referer( 'ai_seo_connect_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Insufficient permissions.' ) );
        }

        $setup_token  = isset( $_POST['setup_token'] ) ? sanitize_text_field( wp_unslash( $_POST['setup_token'] ) ) : '';
        $platform_url = isset( $_POST['platform_url'] ) ? esc_url_raw( wp_unslash( $_POST['platform_url'] ) ) : '';
        $platform_url = self::normalize_platform_url( $platform_url );
        $wp_token     = AI_SEO_Activator::get_token();
        $site_url     = get_site_url();
        $site_name    = get_bloginfo( 'name' );

        if ( empty( $setup_token ) || empty( $platform_url ) ) {
            wp_send_json_error( array( 'message' => 'Please enter the setup token and platform URL.' ) );
        }

        $url      = trailingslashit( $platform_url ) . 'api/v1/connectors/wordpress/plugin/register';
        $response = wp_remote_post(
            $url,
            array(
                'method'  => 'POST',
                'timeout' => 15,
                'headers' => array( 'Content-Type' => 'application/json' ),
                'body'    => wp_json_encode(
                    array(
                        'setup_token' => $setup_token,
                        'wp_token'    => $wp_token,
                        'site_url'    => $site_url,
                        'site_name'   => $site_name,
                    )
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( array( 'message' => 'Connection failed. Check Platform URL.' ) );
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        // The backend wraps every response in the unified envelope:
        // {"status": true, "message": "Success", "data": {success, project_name, ...}}.
        // The register payload (success flag + project_name) lives under `data`.
        $data = ( is_array( $body ) && isset( $body['data'] ) && is_array( $body['data'] ) )
            ? $body['data']
            : array();

        if ( 200 === $code && ! empty( $data['success'] ) ) {
            $project_name = isset( $data['project_name'] ) ? $data['project_name'] : '';
            update_option( 'ai_seo_connection_status', 'connected' );
            update_option( 'ai_seo_connected_project', $project_name );
            update_option( 'ai_seo_platform_url', $platform_url );
            wp_send_json_success( array( 'project_name' => $project_name ) );
        }

        if ( 404 === $code ) {
            wp_send_json_error( array( 'message' => 'Invalid or expired setup token' ) );
        }
        if ( 400 === $code ) {
            wp_send_json_error( array( 'message' => 'Site URL does not match project domain' ) );
        }
        wp_send_json_error( array( 'message' => 'Connection failed. Check Platform URL.' ) );
    }

    /**
     * AJAX: clear the saved connection so the page reverts to the connect form.
     */
    public static function handle_disconnect(): void {
        check_ajax_referer( 'ai_seo_connect_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Insufficient permissions.' ) );
        }

        delete_option( 'ai_seo_connection_status' );
        delete_option( 'ai_seo_connected_project' );
        wp_send_json_success();
    }
}
