<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * READ API — exposes published content + SEO meta to the AI SEO Platform.
 *
 * Endpoint: POST /wp-json/ai-seo/v1/extract-context
 * Auth:     X-AI-SEO-Token header, validated by AI_SEO_Activator::validate_token().
 */
class AI_SEO_Read_API {

    /**
     * Register the /extract-context REST route.
     * Hooked statically on rest_api_init by ai-seo-platform.php.
     */
    public static function register_routes(): void {
        $controller = new self();

        register_rest_route(
            'ai-seo/v1',
            '/extract-context',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $controller, 'handle_extract' ),
                'permission_callback' => array( 'AI_SEO_Activator', 'validate_token' ),
            )
        );
    }

    /**
     * Return every published post and page, plus every category / tag taxonomy
     * term, with title, content, slug, permalink, and Yoast / Rank Math SEO meta
     * as a flat JSON array. Term items carry term_id + object_type="term" so the
     * crawler can route them to the term apply path; post items are unchanged.
     *
     * @param WP_REST_Request $request The incoming REST request.
     */
    public function handle_extract( WP_REST_Request $request ) {
        nocache_headers();

        $posts = get_posts(
            array(
                'post_type'        => array( 'post', 'page' ),
                'post_status'      => 'publish',
                'numberposts'      => -1,
                'orderby'          => 'ID',
                'order'            => 'ASC',
                'suppress_filters' => false,
            )
        );

        $result = array();

        foreach ( $posts as $post ) {
            $result[] = array(
                'post_id'           => (int) $post->ID,
                'post_type'         => $post->post_type,
                'title'             => $post->post_title,
                'content'           => $post->post_content,
                'slug'              => $post->post_name,
                'permalink'         => get_permalink( $post->ID ),
                'yoast_title'       => get_post_meta( $post->ID, '_yoast_wpseo_title', true ),
                'yoast_description' => get_post_meta( $post->ID, '_yoast_wpseo_metadesc', true ),
                'rank_math_title'   => get_post_meta( $post->ID, '_rank_math_title', true ),
                'rank_math_desc'    => get_post_meta( $post->ID, '_rank_math_description', true ),
            );
        }

        $terms = get_terms(
            array(
                'taxonomy'   => array( 'category', 'post_tag' ),
                'hide_empty' => false,
            )
        );

        if ( ! is_wp_error( $terms ) ) {
            foreach ( $terms as $term ) {
                $permalink = get_term_link( $term );
                if ( is_wp_error( $permalink ) ) {
                    continue;
                }

                $result[] = array(
                    'term_id'           => (int) $term->term_id,
                    'object_type'       => 'term',
                    'taxonomy'          => $term->taxonomy,
                    'title'             => $term->name,
                    'name'              => $term->name,
                    'content'           => $term->description,
                    'description'       => $term->description,
                    'slug'              => $term->slug,
                    'permalink'         => $permalink,
                    'url'               => $permalink,
                    'yoast_title'       => get_term_meta( $term->term_id, '_yoast_wpseo_title', true ),
                    'yoast_description' => get_term_meta( $term->term_id, '_yoast_wpseo_metadesc', true ),
                    'rank_math_title'   => get_term_meta( $term->term_id, 'rank_math_title', true ),
                    'rank_math_desc'    => get_term_meta( $term->term_id, 'rank_math_description', true ),
                );
            }
        }

        wp_send_json( $result );
    }
}
