<?php
/**
 * Report WordPress 404 hits to Howeyah Rank so archived/renamed URLs
 * (still crawled by Google) appear in the broken-pages list for redirects.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AI_SEO_404_Tracker {

    /**
     * Hook into the front-end 404 template.
     */
    public static function register(): void {
        add_action( 'template_redirect', array( self::class, 'maybe_report_404' ), 1 );
    }

    /**
     * When the request is a 404 and the plugin is connected, notify the platform.
     * Non-blocking: failures never affect the visitor experience.
     */
    public static function maybe_report_404(): void {
        if ( ! is_404() || is_admin() ) {
            return;
        }
        if ( get_option( 'ai_seo_connection_status' ) !== 'connected' ) {
            return;
        }

        $platform_url  = (string) get_option( 'ai_seo_platform_url', '' );
        $project_token = (string) get_option( 'ai_seo_project_token', '' );
        if ( $platform_url === '' || $project_token === '' ) {
            return;
        }

        $scheme = is_ssl() ? 'https' : 'http';
        $host   = isset( $_SERVER['HTTP_HOST'] ) ? wp_unslash( $_SERVER['HTTP_HOST'] ) : '';
        $uri    = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
        if ( $host === '' || $uri === '' ) {
            return;
        }

        $url      = $scheme . '://' . $host . $uri;
        $referrer = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';
        $endpoint = trailingslashit( $platform_url ) . 'api/v1/track/404';

        // Fire-and-forget: short timeout, no waiting on response body.
        wp_remote_post(
            $endpoint,
            array(
                'timeout'  => 2,
                'blocking' => false,
                'headers'  => array( 'Content-Type' => 'application/json' ),
                'body'     => wp_json_encode(
                    array(
                        'url'           => $url,
                        'referrer'      => $referrer ? $referrer : null,
                        'project_token' => $project_token,
                    )
                ),
            )
        );
    }
}
