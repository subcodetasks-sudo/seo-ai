<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AI_SEO_Activator {

    public static function activate(): void {
        $existing_token = get_option( AI_SEO_BRIDGE_TOKEN_KEY );
        if ( empty( $existing_token ) ) {
            // Generate 64-char cryptographically random token
            // wp_generate_password(length, special_chars, extra_special_chars)
            $token = wp_generate_password( 64, true, true );
            update_option( AI_SEO_BRIDGE_TOKEN_KEY, $token );
        }
        flush_rewrite_rules();
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
        // Do NOT delete the token on deactivation — only on uninstall
    }

    /**
     * Retrieve and validate the stored token.
     * Returns the token string or empty string if not set.
     */
    public static function get_token(): string {
        return (string) get_option( AI_SEO_BRIDGE_TOKEN_KEY, '' );
    }

    /**
     * Validate X-AI-SEO-Token header against stored token.
     * Returns true if valid, false otherwise.
     * Uses hash_equals() for timing-safe comparison.
     */
    public static function validate_token( WP_REST_Request $request ): bool {
        $stored_token   = self::get_token();
        $provided_token = $request->get_header( 'X-AI-SEO-Token' );

        if ( empty( $stored_token ) || empty( $provided_token ) ) {
            return false;
        }

        return hash_equals( $stored_token, $provided_token );
    }
}
