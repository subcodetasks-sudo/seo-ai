<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * WRITE API — applies AI-generated SEO changes to a published post/page.
 *
 * Endpoint: POST /wp-json/ai-seo/v1/apply-changes
 * Auth:     X-AI-SEO-Token header, validated by AI_SEO_Activator::validate_token().
 *
 * Writes are routed to the active SEO plugin's meta keys (Yoast / Rank Math)
 * or to native fallback keys when neither plugin is active.
 */
class AI_SEO_Write_API {

    /**
     * Register the /apply-changes REST route.
     * Hooked statically on rest_api_init by ai-seo-platform.php.
     */
    public static function register_routes(): void {
        $controller = new self();

        register_rest_route(
            'ai-seo/v1',
            '/apply-changes',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $controller, 'handle_apply' ),
                'permission_callback' => array( 'AI_SEO_Activator', 'validate_token' ),
            )
        );
    }

    /**
     * Apply a batch of changes to a single post.
     *
     * @param WP_REST_Request $request The incoming REST request.
     */
    public function handle_apply( WP_REST_Request $request ) {
        // Route option_key payloads (home/static pages whose SEO lives in
        // wp_options, not post_meta) to the options layer. This must be checked
        // BEFORE post_id so it never intercepts a post/product or term payload.
        $body = $request->get_json_params();
        if ( ! is_array( $body ) ) {
            $body = array();
        }

        // A page_url-only payload (no ids) may still target a real post — e.g.
        // h1/content suggestions whose platform row stored no post_id. Try to
        // resolve the post from the URL first; only unresolvable URLs fall
        // through to the option (home/static SEO) handler.
        if ( ! isset( $body['post_id'] ) && ! isset( $body['term_id'] )
            && ! isset( $body['option_key'] ) && isset( $body['page_url'] ) ) {
            $resolved_id = url_to_postid( esc_url_raw( (string) $body['page_url'] ) );
            if ( $resolved_id > 0 ) {
                $body['post_id'] = $resolved_id;
                $request->set_param( 'post_id', $resolved_id );
            }
        }

        if ( isset( $body['option_key'] )
            || ( ! isset( $body['post_id'] ) && ! isset( $body['term_id'] ) && isset( $body['page_url'] ) ) ) {
            $changes = $body['changes'] ?? array();
            if ( empty( $changes ) || ! is_array( $changes ) ) {
                return wp_send_json_error( array( 'message' => 'No changes provided' ), 400 );
            }
            return $this->handle_option_changes( $changes, $body['option_key'] ?? null );
        }

        // Route term_id payloads (category / tag taxonomy pages whose SEO lives
        // in term meta — or, for Yoast, the wpseo_taxonomy_meta option). Checked
        // AFTER option_key (above) and BEFORE post_id (below) so a {term_id,
        // changes} payload is never misrouted to the post handler.
        if ( isset( $body['term_id'] ) ) {
            $term_id = (int) $body['term_id'];
            if ( ! $term_id ) {
                return wp_send_json_error( array( 'message' => 'Missing term_id' ), 400 );
            }
            $changes = $body['changes'] ?? array();
            if ( empty( $changes ) || ! is_array( $changes ) ) {
                return wp_send_json_error( array( 'message' => 'No changes provided' ), 400 );
            }
            return $this->handle_term_changes( $term_id, $changes );
        }

        $post_id = (int) $request->get_param( 'post_id' );
        if ( ! $post_id ) {
            return wp_send_json_error( array( 'message' => 'Missing post_id' ), 400 );
        }

        $changes = $request->get_param( 'changes' );
        if ( empty( $changes ) || ! is_array( $changes ) ) {
            return wp_send_json_error( array( 'message' => 'No changes provided' ), 400 );
        }

        $post = get_post( $post_id );
        if ( null === $post || 'publish' !== $post->post_status ) {
            return wp_send_json_error( array( 'message' => 'Post not found' ), 404 );
        }

        $seo_plugin     = $this->detect_seo_plugin();
        $fields_updated = array();

        foreach ( $changes as $change ) {
            $field = $this->apply_change( $post_id, $change, $seo_plugin );
            if ( null !== $field ) {
                $fields_updated[] = $field;
            }
        }

        return wp_send_json(
            array(
                'success'        => true,
                'post_id'        => $post_id,
                'fields_updated' => $fields_updated,
            )
        );
    }

    /**
     * Detect the active SEO plugin.
     *
     * @return string 'yoast' | 'rankmath' | 'native'
     */
    private function detect_seo_plugin(): string {
        include_once ABSPATH . 'wp-admin/includes/plugin.php';

        if ( is_plugin_active( 'wordpress-seo/wp-seo.php' ) ) {
            return 'yoast';
        }
        if ( is_plugin_active( 'seo-by-rank-math/rank-math.php' ) ) {
            return 'rankmath';
        }
        return 'native';
    }

    /**
     * Apply a single change to the post and return the change_type that was
     * written, or null for an unknown change_type (skipped silently).
     *
     * @param int    $post_id    Target post ID.
     * @param array  $change     Single change record from the payload.
     * @param string $seo_plugin Active SEO plugin slug.
     * @return string|null
     */
    private function apply_change( int $post_id, $change, string $seo_plugin ): ?string {
        if ( ! is_array( $change ) || empty( $change['change_type'] ) ) {
            return null;
        }

        $change_type = $change['change_type'];
        $new_value   = $this->sanitize_value( $change['new_value'] ?? '' );

        switch ( $change_type ) {
            case 'meta_title':
                if ( 'yoast' === $seo_plugin ) {
                    update_post_meta( $post_id, '_yoast_wpseo_title', $new_value );
                } elseif ( 'rankmath' === $seo_plugin ) {
                    update_post_meta( $post_id, '_rank_math_title', $new_value );
                } else {
                    update_post_meta( $post_id, '_seo_title', $new_value );
                }
                return 'meta_title';

            case 'meta_description':
                if ( 'yoast' === $seo_plugin ) {
                    update_post_meta( $post_id, '_yoast_wpseo_metadesc', $new_value );
                } elseif ( 'rankmath' === $seo_plugin ) {
                    update_post_meta( $post_id, '_rank_math_description', $new_value );
                } else {
                    update_post_meta( $post_id, '_seo_description', $new_value );
                }
                return 'meta_description';

            case 'schema':
                update_post_meta( $post_id, '_ai_seo_schema', $new_value );
                return 'schema';

            case 'faq':
                update_post_meta( $post_id, '_ai_seo_faq', $new_value );
                return 'faq';

            case 'redirect':
                update_post_meta( $post_id, '_ai_seo_redirect', $new_value );
                return 'redirect';

            case 'h1':
                return $this->apply_h1_change( $post_id, $new_value );

            case 'content_append':
                return $this->apply_content_append( $post_id, $change['new_value'] ?? '' );

            default:
                return null;
        }
    }

    /**
     * Apply an H1 change to a post.
     *
     * Most themes render post_title as the visible H1. If the post content
     * itself contains an <h1>, its text is replaced (first occurrence only);
     * otherwise post_title is updated so the rendered H1 changes.
     *
     * @param int    $post_id   Target post ID.
     * @param string $new_value Sanitized new H1 text (plain text).
     * @return string|null 'h1' on success, null when the post is missing.
     */
    private function apply_h1_change( int $post_id, string $new_value ): ?string {
        $new_value = trim( wp_strip_all_tags( $new_value ) );
        if ( '' === $new_value ) {
            return null;
        }

        $post = get_post( $post_id );
        if ( null === $post ) {
            return null;
        }

        $content = (string) $post->post_content;
        if ( preg_match( '/<h1\b[^>]*>.*?<\/h1>/is', $content ) ) {
            $updated = preg_replace_callback(
                '/(<h1\b[^>]*>).*?(<\/h1>)/is',
                static function ( $m ) use ( $new_value ) {
                    return $m[1] . esc_html( $new_value ) . $m[2];
                },
                $content,
                1
            );
            wp_update_post(
                array(
                    'ID'           => $post_id,
                    'post_content' => $updated,
                )
            );
            return 'h1';
        }

        // No <h1> in the content — the theme renders post_title as the H1.
        wp_update_post(
            array(
                'ID'         => $post_id,
                'post_title' => $new_value,
            )
        );
        return 'h1';
    }

    /**
     * Append AI-suggested content sections to a post's content.
     *
     * Append-only by design: existing content is never modified or removed.
     * The HTML is filtered through wp_kses_post so only standard post markup
     * survives.
     *
     * @param int   $post_id Target post ID.
     * @param mixed $html    Raw HTML sections from the payload.
     * @return string|null 'content_append' on success, null when skipped.
     */
    private function apply_content_append( int $post_id, $html ): ?string {
        $html = wp_kses_post( (string) $html );
        if ( '' === trim( $html ) ) {
            return null;
        }

        $post = get_post( $post_id );
        if ( null === $post ) {
            return null;
        }

        wp_update_post(
            array(
                'ID'           => $post_id,
                'post_content' => rtrim( (string) $post->post_content ) . "\n\n" . $html,
            )
        );
        return 'content_append';
    }

    /**
     * Apply a batch of option changes for a static/home page.
     *
     * Home/static pages store their SEO in wp_options (not post_meta), under the
     * active SEO plugin's own option array. Detection reuses detect_seo_plugin().
     * The whole option array is read, only the relevant key is updated, and the
     * full array is written back via update_option() — never raw SQL, and never
     * overwriting the whole option with a single value.
     *
     * @param array       $changes         List of {change_type, new_value} records.
     * @param string|null $option_key_hint Optional hint (may be null; the plugin
     *                                      derives the real keys from detection).
     */
    private function handle_option_changes( $changes, $option_key_hint ) {
        try {
            $seo_plugin     = $this->detect_seo_plugin();
            $fields_updated = array();

            foreach ( $changes as $change ) {
                $field = $this->apply_option_change( $change, $seo_plugin );
                if ( null !== $field ) {
                    $fields_updated[] = $field;
                }
            }

            return wp_send_json_success(
                array(
                    'applied'        => true,
                    'type'           => 'option',
                    'seo_plugin'     => $seo_plugin,
                    'fields_updated' => $fields_updated,
                )
            );
        } catch ( \Throwable $e ) {
            return wp_send_json_error( array( 'message' => $e->getMessage() ), 500 );
        }
    }

    /**
     * Apply a single option change to the active SEO plugin's home settings.
     * Returns the change_type written, or null for an unrecognized change_type.
     *
     * Option-key mapping per SEO plugin:
     *   Yoast    → wpseo_titles['title-home-wpseo' | 'metadesc-home-wpseo']
     *   RankMath → rank_math_titles['homepage_title' | 'homepage_description']
     *   Native   → update_option('blogname' | 'blogdescription', ...)
     *
     * @param array  $change     Single change record from the payload.
     * @param string $seo_plugin Active SEO plugin slug.
     * @return string|null
     */
    private function apply_option_change( $change, string $seo_plugin ): ?string {
        if ( ! is_array( $change ) || empty( $change['change_type'] ) ) {
            return null;
        }

        $change_type = $change['change_type'];
        $new_value   = $this->sanitize_value( $change['new_value'] ?? '' );

        if ( 'yoast' === $seo_plugin ) {
            $titles = get_option( 'wpseo_titles', array() );
            if ( ! is_array( $titles ) ) {
                $titles = array();
            }
            if ( 'meta_title' === $change_type ) {
                $titles['title-home-wpseo'] = $new_value;
            } elseif ( 'meta_description' === $change_type ) {
                $titles['metadesc-home-wpseo'] = $new_value;
            } else {
                return null;
            }
            update_option( 'wpseo_titles', $titles );
            return $change_type;
        }

        if ( 'rankmath' === $seo_plugin ) {
            $titles = get_option( 'rank_math_titles', array() );
            if ( ! is_array( $titles ) ) {
                $titles = array();
            }
            if ( 'meta_title' === $change_type ) {
                $titles['homepage_title'] = $new_value;
            } elseif ( 'meta_description' === $change_type ) {
                $titles['homepage_description'] = $new_value;
            } else {
                return null;
            }
            update_option( 'rank_math_titles', $titles );
            return $change_type;
        }

        // Native WP (no SEO plugin): blogname / blogdescription.
        if ( 'meta_title' === $change_type ) {
            update_option( 'blogname', $new_value );
            return $change_type;
        }
        if ( 'meta_description' === $change_type ) {
            update_option( 'blogdescription', $new_value );
            return $change_type;
        }

        return null;
    }

    /**
     * Apply a batch of changes to a single taxonomy term (category / tag).
     *
     * Mirrors handle_option_changes(): detection is shared via
     * detect_seo_plugin(), each change is dispatched individually, and the
     * success/error envelope matches the option handler. Yoast term SEO lives in
     * the wpseo_taxonomy_meta option (read-modify-write); RankMath and native WP
     * use term meta. Never raw SQL.
     *
     * @param int   $term_id The target term ID.
     * @param array $changes List of {change_type, new_value} records.
     */
    private function handle_term_changes( int $term_id, $changes ) {
        try {
            $seo_plugin     = $this->detect_seo_plugin();
            $fields_updated = array();

            foreach ( $changes as $change ) {
                $field = $this->apply_term_change( $term_id, $change, $seo_plugin );
                if ( null !== $field ) {
                    $fields_updated[] = $field;
                }
            }

            return wp_send_json_success(
                array(
                    'applied'        => true,
                    'type'           => 'term',
                    'term_id'        => $term_id,
                    'seo_plugin'     => $seo_plugin,
                    'fields_updated' => $fields_updated,
                )
            );
        } catch ( \Throwable $e ) {
            return wp_send_json_error( array( 'message' => $e->getMessage() ), 500 );
        }
    }

    /**
     * Apply a single change to a term. Returns the change_type written, or null
     * for an unrecognized change_type.
     *
     * Term SEO meta storage per plugin:
     *   Yoast    → wpseo_taxonomy_meta[ taxonomy ][ term_id ]['wpseo_title' | 'wpseo_desc']
     *   RankMath → term meta rank_math_title | rank_math_description
     *   Native   → term meta _seo_title | _seo_description  (same keys the post
     *              handler uses for native fallback)
     *
     * @param int    $term_id    Target term ID.
     * @param array  $change     Single change record from the payload.
     * @param string $seo_plugin Active SEO plugin slug.
     * @return string|null
     */
    private function apply_term_change( int $term_id, $change, string $seo_plugin ): ?string {
        if ( ! is_array( $change ) || empty( $change['change_type'] ) ) {
            return null;
        }

        $change_type = $change['change_type'];
        $new_value   = $this->sanitize_value( $change['new_value'] ?? '' );

        if ( 'yoast' === $seo_plugin ) {
            return $this->apply_yoast_term_change( $term_id, $change_type, $new_value );
        }

        if ( 'rankmath' === $seo_plugin ) {
            if ( 'meta_title' === $change_type ) {
                update_term_meta( $term_id, 'rank_math_title', $new_value );
                return 'meta_title';
            }
            if ( 'meta_description' === $change_type ) {
                update_term_meta( $term_id, 'rank_math_description', $new_value );
                return 'meta_description';
            }
            return null;
        }

        // Native WP (no SEO plugin): same fallback keys as the post handler.
        if ( 'meta_title' === $change_type ) {
            update_term_meta( $term_id, '_seo_title', $new_value );
            return 'meta_title';
        }
        if ( 'meta_description' === $change_type ) {
            update_term_meta( $term_id, '_seo_description', $new_value );
            return 'meta_description';
        }

        return null;
    }

    /**
     * Apply a single Yoast term change via the wpseo_taxonomy_meta option.
     *
     * Yoast keys term SEO as wpseo_taxonomy_meta[ taxonomy ][ term_id ] with the
     * nested keys 'wpseo_title' / 'wpseo_desc'. The whole option is read, only
     * this term's single key is updated, and the full array is written back via
     * update_option() — the same read-modify-write handle_option_changes() uses,
     * so sibling terms and other taxonomies are preserved. No raw SQL.
     *
     * @param int    $term_id     Target term ID.
     * @param string $change_type 'meta_title' | 'meta_description'.
     * @param string $new_value   Already sanitized value.
     * @return string|null
     */
    private function apply_yoast_term_change( int $term_id, string $change_type, string $new_value ): ?string {
        if ( 'meta_title' === $change_type ) {
            $key = 'wpseo_title';
        } elseif ( 'meta_description' === $change_type ) {
            $key = 'wpseo_desc';
        } else {
            return null;
        }

        $taxonomy = $this->resolve_term_taxonomy( $term_id );
        if ( '' === $taxonomy ) {
            return null;
        }

        $tax_meta = get_option( 'wpseo_taxonomy_meta', array() );
        if ( ! is_array( $tax_meta ) ) {
            $tax_meta = array();
        }
        if ( ! isset( $tax_meta[ $taxonomy ] ) || ! is_array( $tax_meta[ $taxonomy ] ) ) {
            $tax_meta[ $taxonomy ] = array();
        }
        if ( ! isset( $tax_meta[ $taxonomy ][ $term_id ] ) || ! is_array( $tax_meta[ $taxonomy ][ $term_id ] ) ) {
            $tax_meta[ $taxonomy ][ $term_id ] = array();
        }

        $tax_meta[ $taxonomy ][ $term_id ][ $key ] = $new_value;
        update_option( 'wpseo_taxonomy_meta', $tax_meta );

        return $change_type;
    }

    /**
     * Resolve a term's taxonomy (needed to key the Yoast wpseo_taxonomy_meta
     * array). Returns '' when the term cannot be resolved, so the caller skips
     * the write rather than guessing a taxonomy.
     *
     * @param int $term_id Target term ID.
     * @return string Taxonomy slug, or '' if unknown.
     */
    private function resolve_term_taxonomy( int $term_id ): string {
        $term = get_term( $term_id );
        if ( $term && ! is_wp_error( $term ) && isset( $term->taxonomy ) ) {
            return (string) $term->taxonomy;
        }
        return '';
    }

    /**
     * Strip control characters from an incoming value before persisting it.
     * Uses preg_replace WITHOUT the /e modifier (no code evaluation).
     *
     * @param mixed $value Raw value from the payload.
     * @return string
     */
    private function sanitize_value( $value ): string {
        $value = (string) $value;
        // Remove non-printable control chars (keep tab, LF, CR).
        return preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $value );
    }
}
