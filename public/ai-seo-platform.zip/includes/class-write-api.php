<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * WRITE API — applies AI-generated SEO changes to a published post/page.
 *
 * Endpoint: POST /wp-json/ai-seo/v1/apply-changes
 * Auth:     X-AI-SEO-Token header, validated by AI_SEO_Activator::validate_token().
 *
 * Writes are routed to the active SEO plugin's meta keys (Yoast / Rank Math)
 * or to native fallback keys when neither plugin is active.
 */
class AI_SEO_Write_API {

    /**
     * Register the /apply-changes REST route.
     * Hooked statically on rest_api_init by ai-seo-platform.php.
     */
    public static function register_routes(): void {
        $controller = new self();

        register_rest_route(
            'ai-seo/v1',
            '/apply-changes',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $controller, 'handle_apply' ),
                'permission_callback' => array( 'AI_SEO_Activator', 'validate_token' ),
            )
        );
    }

    /**
     * Apply a batch of changes to a single post.
     *
     * @param WP_REST_Request $request The incoming REST request.
     */
    public function handle_apply( WP_REST_Request $request ) {
        $post_id = (int) $request->get_param( 'post_id' );
        if ( ! $post_id ) {
            return wp_send_json_error( array( 'message' => 'Missing post_id' ), 400 );
        }

        $changes = $request->get_param( 'changes' );
        if ( empty( $changes ) || ! is_array( $changes ) ) {
            return wp_send_json_error( array( 'message' => 'No changes provided' ), 400 );
        }

        $post = get_post( $post_id );
        if ( null === $post || 'publish' !== $post->post_status ) {
            return wp_send_json_error( array( 'message' => 'Post not found' ), 404 );
        }

        $seo_plugin     = $this->detect_seo_plugin();
        $fields_updated = array();

        foreach ( $changes as $change ) {
            $field = $this->apply_change( $post_id, $change, $seo_plugin );
            if ( null !== $field ) {
                $fields_updated[] = $field;
            }
        }

        return wp_send_json(
            array(
                'success'        => true,
                'post_id'        => $post_id,
                'fields_updated' => $fields_updated,
            )
        );
    }

    /**
     * Detect the active SEO plugin.
     *
     * @return string 'yoast' | 'rankmath' | 'native'
     */
    private function detect_seo_plugin(): string {
        include_once ABSPATH . 'wp-admin/includes/plugin.php';

        if ( is_plugin_active( 'wordpress-seo/wp-seo.php' ) ) {
            return 'yoast';
        }
        if ( is_plugin_active( 'seo-by-rank-math/rank-math.php' ) ) {
            return 'rankmath';
        }
        return 'native';
    }

    /**
     * Apply a single change to the post and return the change_type that was
     * written, or null for an unknown change_type (skipped silently).
     *
     * @param int    $post_id    Target post ID.
     * @param array  $change     Single change record from the payload.
     * @param string $seo_plugin Active SEO plugin slug.
     * @return string|null
     */
    private function apply_change( int $post_id, $change, string $seo_plugin ): ?string {
        if ( ! is_array( $change ) || empty( $change['change_type'] ) ) {
            return null;
        }

        $change_type = $change['change_type'];
        $new_value   = $this->sanitize_value( $change['new_value'] ?? '' );

        switch ( $change_type ) {
            case 'meta_title':
                if ( 'yoast' === $seo_plugin ) {
                    update_post_meta( $post_id, '_yoast_wpseo_title', $new_value );
                } elseif ( 'rankmath' === $seo_plugin ) {
                    update_post_meta( $post_id, '_rank_math_title', $new_value );
                } else {
                    update_post_meta( $post_id, '_seo_title', $new_value );
                }
                return 'meta_title';

            case 'meta_description':
                if ( 'yoast' === $seo_plugin ) {
                    update_post_meta( $post_id, '_yoast_wpseo_metadesc', $new_value );
                } elseif ( 'rankmath' === $seo_plugin ) {
                    update_post_meta( $post_id, '_rank_math_description', $new_value );
                } else {
                    update_post_meta( $post_id, '_seo_description', $new_value );
                }
                return 'meta_description';

            case 'schema':
                update_post_meta( $post_id, '_ai_seo_schema', $new_value );
                return 'schema';

            case 'faq':
                update_post_meta( $post_id, '_ai_seo_faq', $new_value );
                return 'faq';

            case 'redirect':
                update_post_meta( $post_id, '_ai_seo_redirect', $new_value );
                return 'redirect';

            default:
                return null;
        }
    }

    /**
     * Strip control characters from an incoming value before persisting it.
     * Uses preg_replace WITHOUT the /e modifier (no code evaluation).
     *
     * @param mixed $value Raw value from the payload.
     * @return string
     */
    private function sanitize_value( $value ): string {
        $value = (string) $value;
        // Remove non-printable control chars (keep tab, LF, CR).
        return preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $value );
    }
}
