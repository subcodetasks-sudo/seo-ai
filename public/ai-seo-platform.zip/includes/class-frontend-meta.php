<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Frontend meta output — renders the native fallback SEO fields written by the
 * WRITE API (_seo_title / _seo_description) on the public site.
 *
 * Without this layer, applying a meta suggestion on a site that has no SEO
 * plugin (Yoast / Rank Math) stores the values in post/term meta but nothing
 * ever prints them, so the visible <title> and meta description never change.
 *
 * Every hook below is a no-op while Yoast or Rank Math is active — those
 * plugins render their own meta keys and must not be duplicated or overridden.
 */
class AI_SEO_Frontend_Meta {

    /**
     * Attach the title filter and head action.
     * Called once from ai-seo-platform.php at load time.
     */
    public static function register(): void {
        $instance = new self();
        add_filter( 'pre_get_document_title', array( $instance, 'filter_document_title' ), 20 );
        add_action( 'wp_head', array( $instance, 'output_meta_description' ), 1 );
    }

    /**
     * Replace the document <title> with the applied _seo_title, if one exists
     * for the current post, page, or taxonomy term.
     *
     * @param string $title The title short-circuit value (usually '').
     * @return string
     */
    public function filter_document_title( $title ) {
        if ( is_admin() || $this->seo_plugin_active() ) {
            return $title;
        }

        $custom = $this->get_custom_field( '_seo_title' );
        if ( '' !== $custom ) {
            return wp_strip_all_tags( $custom );
        }
        return $title;
    }

    /**
     * Print a <meta name="description"> tag from the applied _seo_description.
     * WordPress core never outputs a meta description on its own, so without
     * an SEO plugin this is the only way the applied value reaches the page.
     */
    public function output_meta_description(): void {
        if ( is_admin() || $this->seo_plugin_active() ) {
            return;
        }

        $desc = $this->get_custom_field( '_seo_description' );

        // Home/static front page: the WRITE API stores its description in the
        // blogdescription option (see apply_option_change), not in post meta.
        if ( '' === $desc && ( is_front_page() || is_home() ) ) {
            $desc = trim( (string) get_option( 'blogdescription', '' ) );
        }

        if ( '' !== $desc ) {
            echo '<meta name="description" content="'
                . esc_attr( wp_strip_all_tags( $desc ) ) . '" />' . "\n";
        }
    }

    /**
     * Read a fallback SEO field for the currently queried object.
     * Posts/pages use post meta; category/tag/taxonomy archives use term meta —
     * the same keys the WRITE API writes in its native (no SEO plugin) path.
     *
     * @param string $key Meta key (_seo_title | _seo_description).
     * @return string Trimmed value, or '' when none is stored.
     */
    private function get_custom_field( string $key ): string {
        if ( is_singular() ) {
            $post_id = get_queried_object_id();
            if ( $post_id ) {
                return trim( (string) get_post_meta( $post_id, $key, true ) );
            }
        }

        if ( is_category() || is_tag() || is_tax() ) {
            $term_id = get_queried_object_id();
            if ( $term_id ) {
                return trim( (string) get_term_meta( $term_id, $key, true ) );
            }
        }

        return '';
    }

    /**
     * Whether Yoast or Rank Math is active. Uses runtime constants/classes
     * instead of is_plugin_active() because that helper is admin-only and this
     * code runs on the frontend.
     *
     * @return bool
     */
    private function seo_plugin_active(): bool {
        return defined( 'WPSEO_VERSION' ) || class_exists( 'RankMath' );
    }
}
