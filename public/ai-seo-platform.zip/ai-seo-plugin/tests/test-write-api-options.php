<?php
/**
 * Manual test script for AI_SEO_Write_API option_key (home/static) handling.
 *
 * Pure PHP — stubs the handful of WordPress functions the handler touches, so
 * no WP install is required. Private methods are exercised via Reflection.
 *
 * Run:  php wordpress-plugin/tests/test-write-api-options.php
 * Exit code 0 = all pass, 1 = at least one failure.
 */

// --------------------------------------------------------------------------- //
// Harness state + WordPress function stubs
// --------------------------------------------------------------------------- //
$GLOBALS['__opts']           = array();  // option store (get_option/update_option)
$GLOBALS['__active_plugins'] = array();  // is_plugin_active source
$GLOBALS['__update_calls']   = array();  // ordered list of update_option keys
$GLOBALS['__json']           = null;     // last wp_send_json* payload
$GLOBALS['__post_meta']      = array();  // update_post_meta sink
$GLOBALS['__term_meta']      = array();  // update_term_meta sink
$GLOBALS['__terms']          = array();  // term_id => taxonomy (get_term source)

if ( ! defined( 'ABSPATH' ) ) {
    // detect_seo_plugin() does include_once ABSPATH.'wp-admin/includes/plugin.php';
    // point ABSPATH at a temp dir and drop an empty stub there.
    $abs = rtrim( sys_get_temp_dir(), '/\\' ) . '/aiseo_test_abs/';
    @mkdir( $abs . 'wp-admin/includes', 0777, true );
    file_put_contents( $abs . 'wp-admin/includes/plugin.php', "<?php\n" );
    define( 'ABSPATH', $abs );
}

function is_plugin_active( $slug ) {
    return in_array( $slug, $GLOBALS['__active_plugins'], true );
}
function get_option( $key, $default = false ) {
    return array_key_exists( $key, $GLOBALS['__opts'] ) ? $GLOBALS['__opts'][ $key ] : $default;
}
function update_option( $key, $value ) {
    $GLOBALS['__opts'][ $key ]   = $value;
    $GLOBALS['__update_calls'][] = $key;
    return true;
}
function update_post_meta( $post_id, $key, $value ) {
    $GLOBALS['__post_meta'][] = array( $post_id, $key, $value );
    return true;
}
function update_term_meta( $term_id, $key, $value ) {
    $GLOBALS['__term_meta'][] = array( $term_id, $key, $value );
    return true;
}
function get_term( $term_id ) {
    // Term registry → object with ->taxonomy, mirroring WP_Term; null if unknown.
    if ( isset( $GLOBALS['__terms'][ $term_id ] ) ) {
        return (object) array( 'term_id' => $term_id, 'taxonomy' => $GLOBALS['__terms'][ $term_id ] );
    }
    return null;
}
class WP_Error {}
function is_wp_error( $thing ) {
    return ( $thing instanceof WP_Error );
}
function get_post( $id ) {
    return null; // Test 3 relies on this → post path returns "Post not found".
}
function wp_send_json_success( $data ) {
    $GLOBALS['__json'] = array( 'success' => true, 'data' => $data );
    return $data;
}
function wp_send_json_error( $data, $code = 0 ) {
    $GLOBALS['__json'] = array( 'success' => false, 'data' => $data, 'code' => $code );
    return $data;
}
function wp_send_json( $data ) {
    $GLOBALS['__json'] = $data;
    return $data;
}

class WP_REST_Request {
    private $body;
    public function __construct( $body ) {
        $this->body = $body;
    }
    public function get_json_params() {
        return $this->body;
    }
    public function get_param( $k ) {
        return isset( $this->body[ $k ] ) ? $this->body[ $k ] : null;
    }
}
class WP_REST_Server {
    const CREATABLE = 'POST';
}

require __DIR__ . '/../includes/class-write-api.php';

// --------------------------------------------------------------------------- //
// Tiny assert harness
// --------------------------------------------------------------------------- //
$GLOBALS['__pass'] = 0;
$GLOBALS['__fail'] = 0;
function check( $cond, $msg ) {
    if ( $cond ) {
        $GLOBALS['__pass']++;
        echo "PASS: $msg\n";
    } else {
        $GLOBALS['__fail']++;
        echo "FAIL: $msg\n";
    }
}
function reset_state() {
    $GLOBALS['__opts']           = array();
    $GLOBALS['__active_plugins'] = array();
    $GLOBALS['__update_calls']   = array();
    $GLOBALS['__json']           = null;
    $GLOBALS['__post_meta']      = array();
    $GLOBALS['__term_meta']      = array();
    $GLOBALS['__terms']          = array();
}
function call_private( $obj, $method, $args ) {
    $r = new ReflectionMethod( $obj, $method );
    $r->setAccessible( true );
    return $r->invokeArgs( $obj, $args );
}

$api = new AI_SEO_Write_API();

// --------------------------------------------------------------------------- //
// Test 1: Yoast path updates correct option key, preserves the rest
// --------------------------------------------------------------------------- //
reset_state();
$GLOBALS['__active_plugins']      = array( 'wordpress-seo/wp-seo.php' );
$GLOBALS['__opts']['wpseo_titles'] = array(
    'title-home-wpseo'    => 'Old',
    'metadesc-home-wpseo' => 'KeepDesc',
    'separator'           => '-',
);
call_private( $api, 'handle_option_changes', array(
    array( array( 'change_type' => 'meta_title', 'new_value' => 'New' ) ),
    null,
) );
check( in_array( 'wpseo_titles', $GLOBALS['__update_calls'], true ), "Test1: update_option('wpseo_titles') called" );
check( $GLOBALS['__opts']['wpseo_titles']['title-home-wpseo'] === 'New', "Test1: title-home-wpseo = 'New'" );
check( $GLOBALS['__opts']['wpseo_titles']['metadesc-home-wpseo'] === 'KeepDesc', "Test1: description key preserved" );
check( $GLOBALS['__opts']['wpseo_titles']['separator'] === '-', "Test1: unrelated key preserved" );

// --------------------------------------------------------------------------- //
// Test 1b: RankMath meta_description updates rank_math_titles (read-modify-write)
// --------------------------------------------------------------------------- //
reset_state();
$GLOBALS['__active_plugins']          = array( 'seo-by-rank-math/rank-math.php' );
$GLOBALS['__opts']['rank_math_titles'] = array( 'homepage_title' => 'KeepT' );
call_private( $api, 'handle_option_changes', array(
    array( array( 'change_type' => 'meta_description', 'new_value' => 'Home Desc' ) ),
    null,
) );
check( $GLOBALS['__opts']['rank_math_titles']['homepage_description'] === 'Home Desc', "Test1b: homepage_description set" );
check( $GLOBALS['__opts']['rank_math_titles']['homepage_title'] === 'KeepT', "Test1b: homepage_title preserved" );

// --------------------------------------------------------------------------- //
// Test 2: Native WP (no SEO plugin) updates blogname / blogdescription
// --------------------------------------------------------------------------- //
reset_state();
call_private( $api, 'handle_option_changes', array(
    array( array( 'change_type' => 'meta_title', 'new_value' => 'Site Name' ) ),
    null,
) );
check( $GLOBALS['__opts']['blogname'] === 'Site Name', "Test2: update_option('blogname') for meta_title" );

reset_state();
call_private( $api, 'handle_option_changes', array(
    array( array( 'change_type' => 'meta_description', 'new_value' => 'Site Desc' ) ),
    null,
) );
check( $GLOBALS['__opts']['blogdescription'] === 'Site Desc', "Test2: update_option('blogdescription') for meta_description" );

// --------------------------------------------------------------------------- //
// Test 2b: null option_key still routes via handle_apply (page_url present)
// --------------------------------------------------------------------------- //
reset_state();
$GLOBALS['__active_plugins'] = array( 'wordpress-seo/wp-seo.php' );
$req = new WP_REST_Request( array(
    'option_key' => null,
    'page_url'   => '/',
    'changes'    => array( array( 'change_type' => 'meta_title', 'new_value' => 'HomeTitle' ) ),
) );
$api->handle_apply( $req );
check( isset( $GLOBALS['__opts']['wpseo_titles']['title-home-wpseo'] )
    && $GLOBALS['__opts']['wpseo_titles']['title-home-wpseo'] === 'HomeTitle', "Test2b: null option_key + page_url routes to option layer" );
check( $GLOBALS['__json']['success'] === true && $GLOBALS['__json']['data']['type'] === 'option', "Test2b: success response type=option" );

// --------------------------------------------------------------------------- //
// Test 3: post_id payload is NOT intercepted by the option branch
// --------------------------------------------------------------------------- //
reset_state();
$req = new WP_REST_Request( array(
    'post_id' => 42,
    'changes' => array( array( 'change_type' => 'meta_title', 'new_value' => 'X' ) ),
) );
$api->handle_apply( $req );
// get_post() stub returns null → the POST path returns "Post not found" (404).
// The option path would instead have produced type=option success. So this proves
// the option branch did not intercept, and no option write happened.
check( empty( $GLOBALS['__opts'] ), "Test3: option branch NOT triggered (no update_option) for post_id payload" );
check( $GLOBALS['__json']['success'] === false
    && $GLOBALS['__json']['data']['message'] === 'Post not found', "Test3: post_id payload routed to the post handler" );

// --------------------------------------------------------------------------- //
// Test 4: term_id payload (Yoast) routes to term handler — wpseo_taxonomy_meta
// updated for the one term/key, sibling term + other key preserved, NOT post.
// --------------------------------------------------------------------------- //
reset_state();
$GLOBALS['__active_plugins']               = array( 'wordpress-seo/wp-seo.php' );
$GLOBALS['__terms'][5]                     = 'category';
$GLOBALS['__opts']['wpseo_taxonomy_meta']  = array(
    'category' => array(
        5 => array( 'wpseo_title' => 'OldT', 'wpseo_desc' => 'KeepDesc' ),
        9 => array( 'wpseo_title' => 'OtherTerm' ),
    ),
);
$req = new WP_REST_Request( array(
    'term_id' => 5,
    'changes' => array( array( 'change_type' => 'meta_title', 'new_value' => 'NewT' ) ),
) );
$api->handle_apply( $req );
check( $GLOBALS['__opts']['wpseo_taxonomy_meta']['category'][5]['wpseo_title'] === 'NewT', "Test4: Yoast term wpseo_title updated" );
check( $GLOBALS['__opts']['wpseo_taxonomy_meta']['category'][5]['wpseo_desc'] === 'KeepDesc', "Test4: same term other key preserved" );
check( $GLOBALS['__opts']['wpseo_taxonomy_meta']['category'][9]['wpseo_title'] === 'OtherTerm', "Test4: sibling term preserved" );
check( $GLOBALS['__json']['success'] === true && $GLOBALS['__json']['data']['type'] === 'term', "Test4: success response type=term (term branch hit)" );
check( empty( $GLOBALS['__post_meta'] ), "Test4: term payload did NOT touch post meta (not post branch)" );

// --------------------------------------------------------------------------- //
// Test 5: RankMath term meta_description → term meta rank_math_description
// --------------------------------------------------------------------------- //
reset_state();
$GLOBALS['__active_plugins'] = array( 'seo-by-rank-math/rank-math.php' );
$GLOBALS['__terms'][7]       = 'post_tag';
$req = new WP_REST_Request( array(
    'term_id' => 7,
    'changes' => array( array( 'change_type' => 'meta_description', 'new_value' => 'Term Desc' ) ),
) );
$api->handle_apply( $req );
$rm_found = false;
foreach ( $GLOBALS['__term_meta'] as $m ) {
    if ( $m === array( 7, 'rank_math_description', 'Term Desc' ) ) {
        $rm_found = true;
    }
}
check( $rm_found, "Test5: RankMath term meta rank_math_description updated" );
check( $GLOBALS['__json']['success'] === true && $GLOBALS['__json']['data']['type'] === 'term', "Test5: RankMath term success type=term" );

// --------------------------------------------------------------------------- //
// Test 6: post_id payload is NOT intercepted by the term branch (regression)
// --------------------------------------------------------------------------- //
reset_state();
$req = new WP_REST_Request( array(
    'post_id' => 42,
    'changes' => array( array( 'change_type' => 'meta_title', 'new_value' => 'X' ) ),
) );
$api->handle_apply( $req );
check( empty( $GLOBALS['__term_meta'] ), "Test6: post_id payload did NOT trigger term handler (no term meta)" );
check( ! isset( $GLOBALS['__opts']['wpseo_taxonomy_meta'] ), "Test6: post_id payload did NOT write wpseo_taxonomy_meta" );
check( $GLOBALS['__json']['success'] === false
    && $GLOBALS['__json']['data']['message'] === 'Post not found', "Test6: post_id still routed to the post handler" );

// --------------------------------------------------------------------------- //
// Test 7: option_key (null) payload is NOT intercepted by the term branch
// --------------------------------------------------------------------------- //
reset_state();
$GLOBALS['__active_plugins'] = array( 'wordpress-seo/wp-seo.php' );
$req = new WP_REST_Request( array(
    'option_key' => null,
    'page_url'   => '/',
    'changes'    => array( array( 'change_type' => 'meta_title', 'new_value' => 'HomeTitle' ) ),
) );
$api->handle_apply( $req );
check( empty( $GLOBALS['__term_meta'] ), "Test7: option payload did NOT trigger term handler" );
check( $GLOBALS['__json']['success'] === true
    && $GLOBALS['__json']['data']['type'] === 'option', "Test7: option payload still routes to option layer (not term)" );

// --------------------------------------------------------------------------- //
// Summary
// --------------------------------------------------------------------------- //
echo "\n{$GLOBALS['__pass']} passed, {$GLOBALS['__fail']} failed\n";
exit( $GLOBALS['__fail'] === 0 ? 0 : 1 );
